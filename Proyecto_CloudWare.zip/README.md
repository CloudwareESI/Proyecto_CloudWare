# Proyecto_CloudWare
CloudWare 3BI ESI Buceo

Este código esta hecho para funcionar con XAMPP y necesita servidor apache e mysql. Se debe cargar el archivo "necesario.sql" antes de usar. Solo es un producto minimo viable para la primera entrega del proyecto de desarrollo web.

El programa hace uso de leaflets y leaflets routing api.