<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="icon" type="image/jpg" href="Imagenes/Logo_quickcarry-sin-fondo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <?php switch ($_SESSION["color"]) { 
        case 'negro':
            ?>
            <link rel="stylesheet" href="estilos/estiloDef.css">
            <?php
            break;
        case 'blanco':
            ?>
            <link rel="stylesheet" href="estilos/estiloColor.css">
            <?php
            break; } 
    ?>
    <title>QuickCarry</title>
</head>

<body>
<header>
        <div class="home">
           <a href="index.php"><i class="fa-solid fa-reply"></i></a>
        </div>
    </header>

<div class="contraseñas">


        <div class="contenedorContraseñas">

        <?php echo "<br>";
	switch ($_SESSION["color"]) { 
            case 'negro':
                echo     
                '<img src="Imagenes/Logo_quickcarry-sin-fondo1.png" alt="logo" height="70px" width="70px">'; 
                break;
            case 'blanco':
                echo     
                '<img src="Imagenes/Logo_quickcarry-VERDE.png" alt="logo" height="70px" width="70px">';
                break; } 
	echo "	<br><h2> CONTRASEÑAS DE PRUEBA </h2><br><p>long65tyco@gmail.com, Long65Rep </p><br>";

	echo "<p>almacenero23@crecom.com, Radiante89Ra</p><br>";

	echo "<p>almacenero23@mail.com, Nata173AB</p><br>";

	echo "<p>camionero23@mail.com, ContraRueda67</p><br></div>";

?>
	
</div>
</body>




