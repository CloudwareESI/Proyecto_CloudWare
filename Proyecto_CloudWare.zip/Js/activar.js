document.addEventListener('DOMContentLoaded', function () {
    const cargaElement = document.querySelector('.carga');
    
  
        cargaElement.style.animationPlayState = 'running';
    
  });