document.addEventListener('DOMContentLoaded', function () {
  const carga1Element = document.querySelector('.carga1');
  const carga2Element = document.querySelector('.carga2');
  const carga3Element = document.querySelector('.carga3');
  const carga4Element = document.querySelector('.carga4');


  
  carga1Element.style.animationPlayState ='running';
  carga2Element.style.animationPlayState ='paused';
  carga3Element.style.animationPlayState ='paused';
  carga4Element.style.animationPlayState ='paused';
});